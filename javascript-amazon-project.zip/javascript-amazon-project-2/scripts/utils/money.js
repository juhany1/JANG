export function fomatCurrency(priceCents){
   return (priceCents/100).toFixed(2)

}
export default fomatCurrency;